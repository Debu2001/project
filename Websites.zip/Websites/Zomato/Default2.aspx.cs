﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default4.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default3.aspx");
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {

    }
    protected void ImageButton11_Click(object sender, ImageClickEventArgs e)
    {

    }
    protected void ImageButton24_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("chinese.aspx");
    }
    protected void ImageButton25_Click1(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Indian.aspx");
    }
    protected void ImageButton26_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Iitalian.aspx");
    }
    protected void ImageButton23_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Thai.aspx");
    }
    protected void ImageButton26_Click1(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Iitalian.aspx");
    }
}