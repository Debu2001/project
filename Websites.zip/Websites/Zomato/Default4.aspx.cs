﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Default4 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DataSet da = new DataSet();
        da = Class1.fetch("select EorP,password from user_data where EorP like ('" + TextBox1.Text.ToString() + "')");
        if (da.Tables[0].Rows.Count > 0)
        {
            Response.Write("<script>alert('SUCCESSFULLY')</script>");
        }
        else
        {
            Response.Write("<script>alert('Please register....')</script>");
        }
        Response.Redirect("Default2.aspx");
    }
    protected void ImageButton1_Click1(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}