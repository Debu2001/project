﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Indian : System.Web.UI.Page
{
    Boolean i;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Default2.aspx");
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (TextBox1.Text != "")
        {
            Class1.save("insert into Indian_cart values('" + "Rice" + "','" + TextBox1.Text.ToString() + "','" + (Int32.Parse(TextBox1.Text) * 60).ToString() + "')");
        }
        if (TextBox2.Text != "")
        {
            Class1.save("insert into Indian_cart values('" + "Jeera Rice" + "','" + TextBox2.Text.ToString() + "','" + (Int32.Parse(TextBox2.Text) * 60).ToString() + "')");
        }
        
    }
    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
       
    }
}