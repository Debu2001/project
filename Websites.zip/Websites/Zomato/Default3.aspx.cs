﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class Default3 : System.Web.UI.Page
{
    Boolean i;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DataSet da = new DataSet();
        da = Class1.fetch("Select EorP from user_data where EorP like ('" + TextBox2.Text.ToString() + "')");
        if (da.Tables[0].Rows.Count > 0)
        {
            Response.Write("<script>alert('Your e-mail id is already exists')</script>" + i);
        }
        else
        {
            if (string.Compare(TextBox3.Text.ToString(), TextBox4.Text.ToString()) == 0)
            {
                i = Class1.save("insert into User_data values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "')");
                Response.Write("<script>alert('SUCCESSFULLY')</script>" + i);
            }
            else
            {
                Response.Write("<script>alert('Password not matched')</script>" + i);
            }
        }
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged1(object sender, EventArgs e)
    {

    }
}